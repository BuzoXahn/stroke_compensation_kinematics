
#include <math.h>
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

#include "global.h"
#include "sensor.h"

#include "nr.h"
#include "nrutil.h"

#define FCONFIG_PARAM	"../conf/config-param.txt"
#define	FCONFIG_SCHED	"../conf/config-sched.txt"
#define	FCONFIG_POS		"../conf/config-pos.txt"
/*
#define	LOGDIR			"../log"
#define	LOGFILE			"../log/log.txt"
*/
#define MAXBUFSZ		4096
#define	MAXLINESZ		32
#define	MAXPARAM		128

    char LOGDIR[255]="../data/";
    char LOGFILE[255]="";
    char temp[255]="/log.txt";

fpos g_pos_data_t;		// the position of a target
fpos g_pos_data_s;		// the position of the first sensor
fpos g_pos_data_s2;		// the position of the first sensor

float g_real_w = 28.8; // 9.9
float g_real_h = 22; // 7.5
float g_real_z = 2.138; //1.0; //0.964; // 1.424;	//1.334;

fmatrix g_calibs, g_calibt, g_matrix;
fpos g_s, g_s2, g_rms[7], g_s_init, g_s2_init;
struct result_data g_result_data[MAXTRIAL];

int cnt_trial = 1, cnt_target = 1, cnt_calib = 1, cnt_rms = 1;
int flag_direction=0;
int w = 640, h = 640, g_scene = SC_CALIB_INFO;
float g_ratio=1.0;
FILE *g_fp = NULL, *g_logfp = NULL;
struct timeval t_end, t_start;

ftarget t_calib = { 0.03, 0.0, 1.0, 0.0 };
ftarget t_ready = { 0.07, 0.0, 1.0, 0.0 };
ftarget t_test  = { 0.07, 1.0, 1.0, 1.0 };

/* A pseudo random sequence is calculated by pseudo.c */
int g_sched[MAXTRIAL];
/* During a pilot test, 50 positions are used to conduct reaching task. */
fpos g_pos_test[MAXTRIAL];
int maxtrial = MAXTRIAL, maxtarget = MAXTARGET, maxtime = 1200;
int ITT=3000;
int session_score=0;
char str_session_score[20];

/*  UDP  */
	char c[1000];
	fd_set rfds;
	struct  timeval tv;
	int udp_id;
	int	nret;


int loadparam(void)
{
	FILE *fp = NULL;
	char *ptr = NULL, *ptrtok = NULL;
	char buf[MAXBUFSZ], bufline[MAXPARAM][MAXLINESZ]; 
	int	i, recv;

	/* initialize */
	i = 0;
	memset(g_s_init, '\0', sizeof(fpos));
	memset(g_s2_init, '\0', sizeof(fpos));
	memset(buf, '\0', MAXBUFSZ);
	memset(bufline, '\0', MAXPARAM*MAXLINESZ);

	/* read a configuration file */
	fp = fopen(FCONFIG_PARAM, "r");
	if ( (recv = fread(buf, 1, MAXBUFSZ, fp)) < 0)
		dprintf(0, "read failed: %s\n", strerror(errno));
	fclose(fp);

	/* extract each parameter */
	ptr = strtok(buf, "\n");
	while (ptr != NULL) {
		dprintf(1, "ptr = %s\n", ptr);
		sprintf(bufline[i++], "%s\n", ptr);
		ptr = strtok(NULL, "\n");
	}

	/* extract each value */
	for (i = 0; strlen(bufline[i]) > 0; i++) {
		ptrtok = strtok(bufline[i], "\t");
		if (ptrtok != NULL) {
			dprintf(1, "ptrtok = %s\n", ptrtok);
			if (strcmp(ptrtok, "MAXTRIAL") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					maxtrial = atoi(ptrtok);
			} else if (strcmp(ptrtok, "MAXTARGET") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					maxtarget = atoi(ptrtok);
			} else if (strcmp(ptrtok, "MAXTIME") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					maxtime=atoi(ptrtok);
			} else if (strcmp(ptrtok, "ITT") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					ITT=atoi(ptrtok);
			} else if (strcmp(ptrtok, "TARGET_RADIUS_CALIB") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					t_calib[0] = atof(ptrtok);
			} else if (strcmp(ptrtok, "TARGET_RADIUS_READY") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					t_ready[0] = atof(ptrtok);
			} else if (strcmp(ptrtok, "TARGET_RADIUS_TEST") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					t_test[0] = atof(ptrtok);
			}
		}
	}

	dprintf(1, "maxtrial  = %d\n", maxtrial);
	dprintf(1, "maxtarget = %d\n", maxtarget);
	dprintf(1, "t_calib = %f\n", t_calib[0]);
	dprintf(1, "t_ready = %f\n", t_ready[0]);
	dprintf(1, "t_test  = %f\n", t_test[0]);


	/* initialize */
	memset(buf, '\0', MAXBUFSZ);
	memset(bufline, '\0', MAXPARAM*MAXLINESZ);
	i = 0;

	/* read a test schedule */
	fp = fopen(FCONFIG_SCHED, "r");
	if ( (recv = fread(buf, 1, MAXBUFSZ, fp)) < 0)
		dprintf(0, "read failed: %s\n", strerror(errno));
	fclose(fp);

	/* extract each parameter */
	ptr = strtok(buf, "\n");
	while (ptr != NULL) {
		g_sched[i++] = atoi(ptr);
		ptr = strtok(NULL, "\n");
	}

	dprintf(1, "g_sched=\n");
	for (i = 0; i < maxtarget; i++) {
		dprintf(1, " %d", g_sched[i]);
	}
	dprintf(1, "\n");


	/* initialize */
	memset(buf, '\0', MAXBUFSZ);
	memset(bufline, '\0', MAXPARAM*MAXLINESZ);
	i = 0;

	/* read target pos_testitions */
	fp = fopen(FCONFIG_POS, "r");
	if ( (recv = fread(buf, 1, MAXBUFSZ, fp)) < 0)
		dprintf(0, "read failed: %s\n", strerror(errno));
	fclose(fp);

	/* extract each parameter */
	ptr = strtok(buf, "\n");
	while (ptr != NULL) {
		sprintf(bufline[i++], "%s\n", ptr);
		ptr = strtok(NULL, "\n");
	}

	/* extract each value */
	for (i = 0; strlen(bufline[i]) > 0; i++) {
		g_pos_test[i][0] = atof(strtok(bufline[i], ","));
		g_pos_test[i][1] = atof(strtok(NULL, ","));
		g_pos_test[i][2] = atof(strtok(NULL, ","));
	}

	dprintf(1, "g_pos_test=\n");
	for (i = 0; i < maxtarget; i++) {
		dprintf(1, "(%.2f,%.2f,%.2f)",
				g_pos_test[i][0], g_pos_test[i][1], g_pos_test[i][2]);
	}
	dprintf(1, "\n");

	if (access(LOGDIR, R_OK) < 0)
		mkdir(LOGDIR, 0777);

	return 0;
}


void reshape(int w1,int h1)
{
	int i;

	if (h1 == 0)
		h1 = 1;

	w = w1;
	h = h1;
	g_ratio = (float)w/(float)h;
	printf("%f\n",g_ratio);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	/* Set the viewport to be the entire window */
    glViewport(0, 0, w1, h1);
	glOrtho(-1.0*g_ratio, 1.0*g_ratio, -1.0, 1.0, 0.0, 20.0);

	for (i = 1; i <= 5; i++)
		g_calibt[1][i] *= g_ratio;

	glMatrixMode(GL_MODELVIEW);
}



void setOrthographicProjection()
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();

	/* set a 2D orthographic projection
	 * let origin be not buttom-left but upper-left */
	gluOrtho2D(0, w, 0, h);
	glScalef(1, -1, 1);
	glTranslatef(0, -h, 0);

	glMatrixMode(GL_MODELVIEW);
}

void resetPerspectiveProjection()
{
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void glprint(float x, float y, char *string)
{
	char *c;
	void *font=GLUT_BITMAP_8_BY_13;
//	void *font=GLUT_BITMAP_HELVETICA_12;
//	void *font=GLUT_BITMAP_TIMES_ROMAN_24;
	glRasterPos2f(x, y);
	for (c=string; *c != '\0'; c++)
		glutBitmapCharacter(font, *c);
}

void glprintbig(float x, float y, char *string)
{
	char *c;
//	void *font=GLUT_BITMAP_9_BY_15;
	void *font=GLUT_BITMAP_HELVETICA_18;
//	void *font=GLUT_BITMAP_TIMES_ROMAN_24;
	glRasterPos2f(x, y);
	for (c=string; *c != '\0'; c++)
		glutBitmapCharacter(font, *c);
}

void glprintbigbig(float x, float y, char *string)
{
	char *c;
//	void *font=GLUT_BITMAP_9_BY_15;
//	void *font=GLUT_BITMAP_HELVETICA_18;
	void *font=GLUT_BITMAP_TIMES_ROMAN_24;
	glRasterPos2f(x, y);
	for (c=string; *c != '\0'; c++)
		glutBitmapCharacter(font, *c);
}
void display_target(ftarget t)
{
	glPushMatrix();
		glLoadIdentity();
		glColor3f(t[1], t[2], t[3]);
		glTranslatef(g_pos_data_t[0], g_pos_data_t[1], g_pos_data_t[2]);
		glutSolidSphere(t[0],20,20);
	glPopMatrix();
}

void display_init()
{
	int i;
	struct timeval tv;
	struct timezone tz;

	gettimeofday(&tv, &tz);
	srandom((unsigned int)tv.tv_usec);
	g_pos_data_t[0] = 0;
	g_pos_data_t[1] = 0;
	g_pos_data_t[2] = -5;

	/* set the matrix to an identity matrix as default */
	g_matrix = matrix(1,3,1,3);
	for (i = 1; i <= 3; i++)
		g_matrix[i][i] = 1.0;

	g_calibs = matrix(1,3,1,5);
	g_calibt = matrix(1,3,1,5);
	g_calibt[1][1]=-0.8;g_calibt[2][1]= 0.8;g_calibt[3][1]=-5.0;
	g_calibt[1][2]= 0.8;g_calibt[2][2]= 0.8;g_calibt[3][2]=-5.0;
	g_calibt[1][3]= 0.8;g_calibt[2][3]=-0.8;g_calibt[3][3]=-5.0;
	g_calibt[1][4]=-0.8;g_calibt[2][4]=-0.8;g_calibt[3][4]=-5.0;
	g_calibt[1][5]= 0.0;g_calibt[2][5]= 0.0;g_calibt[3][5]=-5.0;

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glutSwapBuffers();
}

void idledisplay()
{
		int temp_read;
	int temp,i, is_reached = 0;
	char s[256], fname[256];
	float error_s1, error_s2, final_error;
	float dist_right, dist_left;

                FD_ZERO(&rfds);
                FD_SET(0, &rfds);
                FD_SET(udp_id, &rfds);

                /* Wait up to one seconds. */
              	tv.tv_sec = 1;
              	tv.tv_usec = 0;

                if( select(20, &rfds, NULL, NULL, &tv ) < 0 )
                        printf("Select error!!![%s]",strerror(errno));

                if(FD_ISSET(udp_id,&rfds))
                {
		nret = ReadMsgFromUnixUDP(udp_id,c,4);
		if( nret > 0 )
			{
			temp_read=(int)(c[0] | c[1]<<8 | c[2] <<16 | c[3]<<24 );
			if (temp_read<50)
				g_scene=temp_read;
			else
				is_reached=temp_read;
			printf("g_scene=%d is_reached=%d dierction=%d\n",g_scene,is_reached,flag_direction);
			}
		}





	/* initialization */
	glLoadIdentity();
	glTranslatef(0, 0, -5);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/* display text */
	/*
	setOrthographicProjection();
	glPushMatrix();
		glColor3f(0.0,1.0,1.0);
		glLoadIdentity();
		glprint(5,10,"Reaching Task Training Program");
		glprint(5,25,"Computational Neuro-Rehabilitation Lab.");
		glprint(5,40,"ESC - Quit");
	glPopMatrix();
	resetPerspectiveProjection();
	*/

	/* display each scene */
	switch (g_scene) {
	case SC_CALIB_INFO:
		setOrthographicProjection();
		glPushMatrix();
			glColor3f(0.0,1.0,1.0);
			glLoadIdentity();
			glprintbig(w/2-130,h/2-60, "STEP 1. SCREEN CALIBRATION");
			glprint(w/2-155,h/2-30, "Five points will be presented sequencially.");
			glprint(w/2-145,h/2-10, "Touch the point and press the ENTER key.");
			glprint(w/2-110,h/2+25, "ENTER - Start or SPACE - Skip");
		glPopMatrix();
		resetPerspectiveProjection();
		break;
	case SC_CALIB_LU:
	case SC_CALIB_RU:
	case SC_CALIB_RB:
	case SC_CALIB_LB:
	case SC_CALIB_C:
		g_pos_data_t[0] = g_calibt[1][cnt_calib];
		g_pos_data_t[1] = g_calibt[2][cnt_calib];
		display_target(t_calib);
		break;

	/* start the test */
	case SC_TEST_INFO:
		setOrthographicProjection();
		glPushMatrix();
			glColor3f(0.0,1.0,1.0);
			glLoadIdentity();
			glprintbig(w/2-100,h/2-60,"STEP 2. TEST SESSION");
			glprint(w/2-110,h/2-20, "ENTER - Start or SPACE - Skip");
		glPopMatrix();
		resetPerspectiveProjection();


		break;
	case SC_TEST_READY1:
		/*
		setOrthographicProjection();
		glPushMatrix();
			glColor3f(0.0,1.0,1.0);
			glLoadIdentity();
			glprint(w/2-110,h-10,"Move when target changes into red.");
		glPopMatrix();
		resetPerspectiveProjection();
		*/

		/* generate new target position at the first trial */
		/*
		g_pos_data_t[0] = g_pos_test[g_sched[cnt_target-1]-1][0]*g_ratio;
		g_pos_data_t[1] = g_pos_test[g_sched[cnt_target-1]-1][1];
		*/

	    if (cnt_target==1)
			sprintf(str_session_score,"0/0");
		else if (cnt_target%10==0)
			sprintf(str_session_score,"%d/9",session_score);
		else if (cnt_target%10==1)
			sprintf(str_session_score,"%d/10",session_score);
		else
			sprintf(str_session_score,"%d/%d",
					session_score,(cnt_target%10-1));
		glprintbigbig(0.5,0.5,str_session_score);
		
 		if ((cnt_target%10)==1)
		{
		  //	if (session_score==10) //(p)
		  //	glprintbigbig(0.5,0.6,"Perfect!!!"); //(p)
			session_score=0;
		}

		g_pos_data_t[0] = 0;
		g_pos_data_t[1] = -0.8;

		display_target(t_ready);

		break;
	case SC_TEST_READY2:
		/* show a direction to a tester for a while(1 sec) */
		/*
		setOrthographicProjection();
		glPushMatrix();
			glColor3f(0.0,1.0,1.0);
			glLoadIdentity();
			glprint(w/2-110,h-10,"Move when target changes into red.");
		glPopMatrix();
		resetPerspectiveProjection();
		*/
			glprintbigbig(0.5,0.5,str_session_score);
//	  flag_direction=0;
	        display_target(t_ready);

		break;
	case SC_TEST_GO:
		/* start a test for reaching task */
		/*
		setOrthographicProjection();
		glPushMatrix();
			glColor3f(0.0,1.0,1.0);
			glLoadIdentity();
			glprintbig(w/2,h-10,"Go!");
		glPopMatrix();
		resetPerspectiveProjection();
		dprintf(1,"Go!\n");
		*/
			glprintbigbig(0.5,0.5,str_session_score);

//	  if (flag_direction==0)
//	    {
		g_pos_data_t[0] =    0 + g_pos_test[g_sched[cnt_target-1]-1][0]/g_real_w*g_ratio;
		g_pos_data_t[1] = -0.8 + g_pos_test[g_sched[cnt_target-1]-1][1]/g_real_h;
//	    }
//	  else
//	    {
//	      g_pos_data_t[0]=0;
//	      g_pos_data_t[1]=-0.8;
//	    }

		display_target(t_test);
		temp=8;		memcpy(c,&temp,sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
		printf("[udp:%d] %d [%d]\n",udp_id,temp,nret);


		/* check whether the target is reached or not */
//		is_reached = check_sensor_pos();

		if ( is_reached>0 ) {
//			if (flag_direction==0 )
//			  {
//			    flag_direction=1;
//				printf("target direction changed(%d)\n",flag_direction);
				if (is_reached==99) //Suceess
				{
				  system("cat success.au > /dev/audio");
				  session_score++;
				  // if (cnt_target%10==0 && session_score==10)// (p)
				  //  glprintbig(0.5,0.6,"PERFECT!!"); // (p)
				}
				else
				  {system("cat failure.au > /dev/audio");}
				is_reached=0;
//			    }
//			else
//			  {
			is_reached = 0;
//				flag_direction=2;		;
//			  }
		} else {
			cnt_trial++;				/* try again with the same target */
		}	/* if (cnt_trial == maxtrial || is_reached) */

		break;
	case SC_TEST_RETURN:
			glprintbigbig(0.5,0.5,str_session_score);
			//	if (cnt_target%10==0 && session_score==10) //(p)
			//  glprintbig(0.5,0.6,"PERFECT!!"); //(p)
			
		g_pos_data_t[0] =    0 ;
		g_pos_data_t[1] = -0.8 ;

		display_target(t_test);
//		gettimeofday(&t_start,NULL);
//		sprintf(s_ts_temp,"%s\t %ld",s_ts_temp,(1000000*t_start.tv_sec+t_start.tv_usec));


		temp=8;		memcpy(c,&temp,sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
		printf("[udp:%d] %d [%d]\n",udp_id,temp,nret);

		if ( is_reached>0 ) {
				system("cat success.au > /dev/audio");
				is_reached=0;
				cnt_target++;
				cnt_trial = 1;
				is_reached = 0;
		} else {
			cnt_trial++;				/* try again with the same target */
		}	/* if (cnt_trial == maxtrial || is_reached) */

		break;

	case SC_END:
	default:
		setOrthographicProjection();
		glPushMatrix();
			glColor3f(0.0,1.0,1.0);
			glLoadIdentity();
			glprintbigbig(w/2-60,h/2-50, "THANK YOU");
		glPopMatrix();
		resetPerspectiveProjection();

		temp=3;		memcpy(c,&temp,sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
		printf("[udp:%d] %s [%d]\n",udp_id,c,nret);
		exit(0);
		break;
	}	/* switch(g_scene) */

	/* finalization */
	glutSwapBuffers();



}

void keyboard(unsigned char key, int x, int y)
{
	int nret;
int temp;

	if (g_scene == SC_END)
		exit(0);

	switch (key) {
	/* go to the next step or go to start */
	case KEY_ENT:
		if (SC_CALIB_LU <= g_scene && g_scene <= SC_CALIB_C) {
			/* screen calibration */
			cnt_calib++;
		}
		temp=1;		memcpy(c,&temp,sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
		printf("[udp:%d] %s [%d]\n",udp_id,c,nret);
		break;

	/* skip this step */
	case KEY_SPACE:
		temp=2;		memcpy(c,&temp,sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
		printf("[udp:%d] %s [%d]\n",udp_id,c,nret);
		break;

	/* end a program */
	case KEY_ESC:
		temp=3;		memcpy(c,&temp,sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
		printf("[udp:%d] %s [%d]\n",udp_id,c,nret);
		exit(0);
	}
}

int main(int argc, char **argv)
{
	/* consider about using a configuration file */
//	sensor_init(2); //deprecated
	int temp;

	udp_id=CreateUnixUDP("./bart_gui.tmp");

	//TO BART_CORE: I AM UP! please send any initial data.
	temp=9;		memcpy(c,&temp,sizeof(int));
	nret=WriteMsgToUnixUDP(udp_id,"./bart_core.tmp",c,4);
	printf("[udp:%d] %s [%d] [sent:%d]\n",udp_id,c,(int)(c[0] | c[1]<<8 | c[2] <<16 | c[3]<<24 ),nret);	

	loadparam();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(0,0);
	glutInitWindowSize(w,h);
	glutCreateWindow("Reaching Task");

	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);
	glutDisplayFunc(display);
	glutIdleFunc(idledisplay);


	display_init();
	glutMainLoop();

	return(0);
}


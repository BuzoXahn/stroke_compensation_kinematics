#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>


#include <strings.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/io.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

#include "global.h"

#include "debug.h"
#include "sensor.h"
#include "command.h"

#include "nr.h"
#include "nrutil.h"

#define MAXBUF	8192

int g_nos = 2;						/* number of sensors */
int cnt = 0;
int t_wait = 2500;

int config_serial()
{
        struct termios oldtio,newtio;

/*Y*/ serfd = open(MODEMDEVICE, O_RDWR | O_NOCTTY | O_SYNC );
///*J*/	serfd = open(MODEMDEVICE, O_RDWR | O_NDELAY ); 
	if (serfd <0) {
		dprintf(0, "no sensor detected : %s\n", strerror(errno));
		return -1;
	}
        tcgetattr(serfd,&oldtio); /* save current port settings */

        bzero(&newtio, sizeof(newtio));
        newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
/*Y*/ 	newtio.c_iflag = IXOFF | IGNPAR | IXON ;
///*J*/	newtio.c_iflag = IXOFF;
        newtio.c_oflag = 0;


        /* set input mode (non-canonical, no echo,...) */
/*Y*/	newtio.c_lflag = 1;
///*J*/	newtio.c_lflag = 0;
/*Y*/	newtio.c_cc[VTIME]    = 0;   /* inter-character timer unused */
///*J*/	newtio.c_cc[VTIME] = 20;   /* inter-character timer unused */
        newtio.c_cc[VMIN]     = 1 ;   /* blocking read until 5 chars received */

/*Y*/// 	tcflush(serfd, TCIFLUSH);
        tcsetattr(serfd,TCSANOW,&newtio);
	
	return 0;
}

void sensor_init(int numberofsensors)
{
	g_nos = numberofsensors;
	posk = POSK36;
	config_serial();
	dprintf(0,"the number of sensors : %d\n", g_nos);

	bird_hemisphere(0);
	bird_autoconfig(numberofsensors);
	setPosPoint();
}

void sensor_finalize()
{
	close(serfd);
}

int main(int argc, char **argv)
{
	int c, i = 0,j;
	float *pos_data_s;
	char s[256], fname[256];
	FILE *fp = NULL;
	time_t tm;
	struct tm *tmp;
	struct timeval t_current, t_start, t_samp_st, t_samp_end;
	struct result_data result_data[MAXBUF];
	float	wristTau,xForce,yForce,zForce;

        int bufsize = 1024*8;
        char *buffer = malloc(bufsize);
	short	birddata[MAXBUFSIZE];

        fd_set  rfds;
        struct  timeval tv;
        int     retval;


//	initADC();

//	sensor_init(2);
config_serial();
pos_data_s = (float *)malloc(3*sizeof(float));

	printf("\nPress any keys to start to recode:");
	c = getchar();

	tm = time(NULL);
	tmp = localtime(&tm);
	strftime(s, 100, "%m%d%Y-%H%M", tmp);
	sprintf(fname, "%s.dat", s);

	if ((fp = fopen(fname, "w+")) == NULL) {
		dprintf(0, "fopen error: %s\n", strerror(errno));
		free(pos_data_s);
//		sensor_finalize();
		exit(0);
	}

	/* start a test */
	gettimeofday(&t_start,NULL);

	int	tSample;
	printf("Opened serial port:%d\n",serfd);
	while (1) {
                /* Watch stdin (fd 0) to see when it has input. */
                FD_ZERO(&rfds);
                FD_SET(0, &rfds);
                FD_SET(serfd, &rfds);

                /* Wait up to five seconds. */
              	tv.tv_sec = 5;
              	tv.tv_usec = 0;

				printf("Before select\n");
                if( select(20, &rfds, NULL, NULL, &tv ) < 0 )
                {
                        printf("Select error!!![%s]",strerror(errno));
                }
				printf("After select\n");

                if(FD_ISSET(serfd,&rfds))
                {
					printf("selected %d\n",serfd);
                        if( (retval=read( serfd, buffer, bufsize ))<0 )
                        {
                                printf("read from serial error:%s", strerror(errno));
                        }
						else
						{
							printf("read retval[%d] data\n", retval);
						}

#if 1
                        printf("received from serial:[%d]\n", retval);
                        for( i=0 ; i<retval; i++)
                             printf("%d %d \n",i,(unsigned)buffer[i]);
                        printf("\n");
#endif

			/* get the position from 1st sensor */
	                /* We can use only 7 bits per character recieved therefore we
	                 * should generate 8th bit by 7th bit. - jylee @ 09.10.05 */
			for (i = 0, j = 0; i < retval; i+=2, j++) {
				buffer[i] &= 0x7F;
				buffer[i+1] |= ((buffer[i+1] & 0x40) << 1);
				birddata[j]=((short)buffer[i]) | (((short)buffer[i+1]) << 8);
			}
			/* write position data to global variables */
			pos_data_s[0] = (float)(birddata[0+0] * posk);
			pos_data_s[1] = (float)(birddata[1+0] * posk);
			pos_data_s[2] = (float)(birddata[2+0] * posk);
//			printf("(1)\t%7.2f\t%7.2f\t%7.2f\n", 
//				pos_data_s[0], pos_data_s[1], pos_data_s[2]);
			dprintf(1, "(1)\t%7.2f\t%7.2f\t%7.2f\n", 
				pos_data_s[0], pos_data_s[1], pos_data_s[2]);
                }



		gettimeofday(&t_samp_st,NULL);
//		sensor_get_pos(pos_data_s);
		gettimeofday(&t_samp_end,NULL);
		tSample = t_samp_end.tv_sec*1000000+t_samp_end.tv_usec; 
//		tSample = (t_samp_st.tv_sec - t_samp_end.tv_sec)*1000000+(t_samp_st.tv_usec-t_samp_end.tv_usec); 


		result_data[i].s[0] = pos_data_s[0];
		result_data[i].s[1] = pos_data_s[1];
		result_data[i].s[2] = pos_data_s[2];

#if 0 

		if( i==3 )
		{
			bird_anglealign(pos_data_s);
			sleep(1);	
			
		}
#endif

		
#if 1
		sprintf(s, "%3.2f  %3.2f  %3.2f  %f  %d  %d  %d  %d \n",
				result_data[i].s[0], result_data[i].s[1], result_data[i].s[2], wristTau, tSample, t_samp_st.tv_usec, t_samp_end.tv_sec, t_samp_end.tv_usec );
#else
		sprintf(s, "%3.2f  %3.2f  %3.2f  %f  %f  %f  %f\n",
				result_data[i].s[0], result_data[i].s[1], result_data[i].s[2], wristTau, xForce, yForce, zForce);
//		printf("%3.2f  %3.2f  %3.2f  %f  %f  %f  %f\n", result_data[i].s[0], result_data[i].s[1], result_data[i].s[2], wristTau, xForce, yForce, zForce);
#endif
		fwrite(s, 1, strlen(s), fp);

		gettimeofday(&t_current,NULL);
		if ((t_current.tv_sec - t_start.tv_sec) > 20) {
			printf("Now exiting..\n");
			break;
		}

		i++;
	}

	/* write to a file */
	if (fp != NULL) {
		fclose(fp);
		fp = NULL;
	}


	free(pos_data_s);

//	sensor_finalize();

	return(0);
}


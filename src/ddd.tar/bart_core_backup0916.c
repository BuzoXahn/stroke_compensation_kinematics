
#include <math.h>
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

#include "global.h"
#include "sensor.h"

#include "nr.h"
#include "nrutil.h"

#define FCONFIG_PARAM	"../conf/config-param.txt"
#define	FCONFIG_SCHED	"../conf/config-sched.txt"
#define	FCONFIG_POS		"../conf/config-pos.txt"
/*
#define	LOGDIR			"../log"
#define	LOGFILE			"../log/log.txt"
*/
#define MAXBUFSZ		4096
#define	MAXLINESZ		32
#define	MAXPARAM		128



    char LOGDIR[255]="../log/";
    char LOGFILE[255]="";
    char temp_char[255]="/log.txt";

fpos g_pos_data_t;		// the position of a target
fpos g_pos_data_s;		// the position of the first sensor
fpos g_pos_data_s2;		// the position of the first sensor

float g_real_w = 28.8; // 9.9
float g_real_h = 22; // 7.5
float g_real_z = 2.138; //1.0; //0.964; // 1.424;	//1.334;

fmatrix g_calibs, g_calibt, g_matrix;
fpos g_s, g_s2, g_rms[7], g_s_init, g_s2_init;
struct result_data g_result_data[MAXTRIAL];

int cnt_trial = 1, cnt_target = 1, cnt_calib = 1, cnt_rms = 1;
int flag_direction=0,selected_hand=0;
int w = 640, h = 640, g_scene = SC_CALIB_INFO;
float g_ratio=1.318229;
FILE *g_fp = NULL, *g_logfp = NULL;
struct timeval t_end, t_start;

ftarget t_calib = { 0.03, 0.0, 1.0, 0.0 };
ftarget t_ready = { 0.07, 1.0, 1.0, 1.0 };
ftarget t_test  = { 0.07, 1.0, 1.0, 1.0 };

/* A pseudo random sequence is calculated by pseudo.c */
int g_sched[MAXTRIAL];
/* During a pilot test, 50 positions are used to conduct reaching task. */
fpos g_pos_test[MAXTRIAL];
int maxtrial = MAXTRIAL, maxtarget = MAXTARGET, maxtime = 900;
int ITT=3000;

/*  UDP  */
	char c[1000];
	fd_set rfds;
	struct  timeval tv;
	int udp_id;
	int	nret;
/* serial for FDSET */
	int serfd;
	int target_displayed_gui=0;
int setup_condition=1;


int loadparam(void)
{
	FILE *fp = NULL;
	char *ptr = NULL, *ptrtok = NULL;
	char buf[MAXBUFSZ], bufline[MAXPARAM][MAXLINESZ]; 
	int	i, recv;

	/* initialize */
	i = 0;
	memset(g_s_init, '\0', sizeof(fpos));
	memset(g_s2_init, '\0', sizeof(fpos));
	memset(buf, '\0', MAXBUFSZ);
	memset(bufline, '\0', MAXPARAM*MAXLINESZ);

	/* read a configuration file */
	fp = fopen(FCONFIG_PARAM, "r");
	if ( (recv = fread(buf, 1, MAXBUFSZ, fp)) < 0)
		dprintf(0, "read failed: %s\n", strerror(errno));
	fclose(fp);

	/* extract each parameter */
	ptr = strtok(buf, "\n");
	while (ptr != NULL) {
		dprintf(1, "ptr = %s\n", ptr);
		sprintf(bufline[i++], "%s\n", ptr);
		ptr = strtok(NULL, "\n");
	}

	/* extract each value */
	for (i = 0; strlen(bufline[i]) > 0; i++) {
		ptrtok = strtok(bufline[i], "\t");
		if (ptrtok != NULL) {
			dprintf(1, "ptrtok = %s\n", ptrtok);
			if (strcmp(ptrtok, "MAXTRIAL") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					maxtrial = atoi(ptrtok);
			} else if (strcmp(ptrtok, "MAXTARGET_FREE") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					if (setup_condition==1)
						maxtarget = atoi(ptrtok);
			} else if (strcmp(ptrtok, "MAXTARGET_FORCED") == 0) {
				ptrtok = strtok(NULL,"\t");
				if (ptrtok != NULL)
					if (setup_condition==0)
						maxtarget = atoi (ptrtok);
			} else if (strcmp(ptrtok, "MAXTIME") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					maxtime=atoi(ptrtok);
			} else if (strcmp(ptrtok, "ITT") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					ITT=atoi(ptrtok);
			} else if (strcmp(ptrtok, "TARGET_RADIUS_CALIB") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					t_calib[0] = atof(ptrtok);
			} else if (strcmp(ptrtok, "TARGET_RADIUS_READY") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					t_ready[0] = atof(ptrtok);
			} else if (strcmp(ptrtok, "TARGET_RADIUS_TEST") == 0) {
				ptrtok = strtok(NULL, "\t");
				if (ptrtok != NULL)
					t_test[0] = atof(ptrtok);
			}
		}
	}

	dprintf(1, "maxtrial  = %d\n", maxtrial);
	dprintf(1, "maxtarget = %d\n", maxtarget);
	dprintf(1, "t_calib = %f\n", t_calib[0]);
	dprintf(1, "t_ready = %f\n", t_ready[0]);
	dprintf(1, "t_test  = %f\n", t_test[0]);


	/* initialize */
	memset(buf, '\0', MAXBUFSZ);
	memset(bufline, '\0', MAXPARAM*MAXLINESZ);
	i = 0;

	/* read a test schedule */
	fp = fopen(FCONFIG_SCHED, "r");
	if ( (recv = fread(buf, 1, MAXBUFSZ, fp)) < 0)
		dprintf(0, "read failed: %s\n", strerror(errno));
	fclose(fp);

	/* extract each parameter */
	ptr = strtok(buf, "\n");
	while (ptr != NULL) {
		g_sched[i++] = atoi(ptr);
		ptr = strtok(NULL, "\n");
	}

	dprintf(1, "g_sched=\n");
	for (i = 0; i < maxtarget; i++) {
		dprintf(1, " %d", g_sched[i]);
	}
	dprintf(1, "\n");


	/* initialize */
	memset(buf, '\0', MAXBUFSZ);
	memset(bufline, '\0', MAXPARAM*MAXLINESZ);
	i = 0;

	/* read target pos_testitions */
	fp = fopen(FCONFIG_POS, "r");
	if ( (recv = fread(buf, 1, MAXBUFSZ, fp)) < 0)
		dprintf(0, "read failed: %s\n", strerror(errno));
	fclose(fp);

	/* extract each parameter */
	ptr = strtok(buf, "\n");
	while (ptr != NULL) {
		sprintf(bufline[i++], "%s\n", ptr);
		ptr = strtok(NULL, "\n");
	}

	/* extract each value */
	for (i = 0; strlen(bufline[i]) > 0; i++) {
		g_pos_test[i][0] = atof(strtok(bufline[i], ","));
		g_pos_test[i][1] = atof(strtok(NULL, ","));
		g_pos_test[i][2] = atof(strtok(NULL, ","));
	}

	dprintf(1, "g_pos_test=\n");
	for (i = 0; i < maxtarget; i++) {
		dprintf(1, "(%.2f,%.2f,%.2f)",
				g_pos_test[i][0], g_pos_test[i][1], g_pos_test[i][2]);
	}
	dprintf(1, "\n");

	if (access(LOGDIR, R_OK) < 0)
		mkdir(LOGDIR, 0777);

	return 0;
}



/* calculate the conversion matrix value */
void calib_screen()
{
	int i, j, k, l;
	float **x[8], **calibs;
	float **c[8];
	float **t[8];
	float **m[8];
	
#if 1
	float **u;
#endif

	for (i=0;i<8;i++) {
		c[i] = matrix(1,3,1,3);
		t[i] = matrix(1,3,1,3);
		m[i] = matrix(1,3,1,3);
	}
	for (i=1;i<=3;i++) {
		for (j=1;j<=3;j++) {
			c[0][i][j]=g_calibs[i][j];
			c[1][i][j]=g_calibs[i][(j==3)?4:j];
			c[2][i][j]=g_calibs[i][(j==3)?5:j];
			c[3][i][j]=g_calibs[i][(j==2)?4:j];
			c[4][i][j]=g_calibs[i][(j==1)?1:j+2];
			c[5][i][j]=g_calibs[i][j+1];
			c[6][i][j]=g_calibs[i][(j==3)?5:j+1];
			c[7][i][j]=g_calibs[i][j+2];

			t[0][i][j]=g_calibt[i][j];
			t[1][i][j]=g_calibt[i][(j==3)?4:j];
			t[2][i][j]=g_calibt[i][(j==3)?5:j];
			t[3][i][j]=g_calibt[i][(j==2)?4:j];
			t[4][i][j]=g_calibt[i][(j==1)?1:j+2];
			t[5][i][j]=g_calibt[i][j+1];
			t[6][i][j]=g_calibt[i][(j==3)?5:j+1];
			t[7][i][j]=g_calibt[i][j+2];
		}
	}

	calibs = matrix(1,3,1,5);
	for (i = 1; i <= 3; i++) {
		for (j = 1; j <= 5; j++)
			calibs[i][j] = g_calibs[i][j];
	}

	/* gauss-jordan elimination to get an inverse matrix */
	for (i=0;i<8;i++) {
		x[i] = matrix(1, 3, 1, 1);
		gaussj(c[i],3,x[i],1);
	}

	for (i=0;i<8;i++) {
		for (k=1;k<=3;k++) {
			for (l=1;l<=3;l++) {
				m[i][k][l]=0.0;
				for (j=1;j<=3;j++)
					m[i][k][l] += (t[i][k][j]*c[i][j][l]);
			}
		}
	}

	for (i=1;i<=3;i++) {
		for (j=1;j<=3;j++) {
			g_matrix[i][j]=0.0;
			for (k=0;k<8;k++)
				g_matrix[i][j] += m[k][i][j];
		}
	}
	for (i=1;i<=3;i++) {
		for (j=1;j<=3;j++)
			g_matrix[i][j] /= 8.0;
	}

//#if (DBG_LVL > 1)
#if 1
	/* just for debugging :) */
	for (k=0;k<8;k++) {
	for (i = 1; i <= 3; i++) {
		dprintf(0, "m[%d]:\t%7.2f\t%7.2f\t%7.2f\n",k,
			m[k][i][1], m[k][i][2], m[k][i][3]);
	}
	}
	for (i = 1; i <= 3; i++) {
		dprintf(0, "g_matrix:\t%7.2f\t%7.2f\t%7.2f\n",
			g_matrix[i][1], g_matrix[i][2], g_matrix[i][3]);
	}

	u = matrix(1,3,1,3);
	printf("\na times a-inverse:\n");
	for (k=1;k<=3;k++) {
		for (l=1;l<=3;l++) {
			u[k][l]=0.0;
			for (j=1;j<=3;j++)
				u[k][l] += (g_calibs[k][j]*c[0][j][l]);
		}
		for (l=1;l<=3;l++) printf("%12.6f",u[k][l]);
		printf("\n");
	}
	x[0][1][1] = g_matrix[1][1]*calibs[1][1] +
			  g_matrix[1][2]*calibs[2][1] +
			  g_matrix[1][3]*calibs[3][1];
	x[0][1][2] = g_matrix[2][1]*calibs[1][1] +
			  g_matrix[2][2]*calibs[2][1] +
			  g_matrix[2][3]*calibs[3][1];
	x[0][1][3] = g_matrix[3][1]*calibs[1][1] +
			  g_matrix[3][2]*calibs[2][1] +
			  g_matrix[3][3]*calibs[3][1];
	printf("1st:");
	for (l=1;l<=3;l++) printf("%12.6f",x[0][1][l]);
	printf("\n");

	x[0][1][1] = g_matrix[1][1]*calibs[1][2] +
			  g_matrix[1][2]*calibs[2][2] +
			  g_matrix[1][3]*calibs[3][2];
	x[0][1][2] = g_matrix[2][1]*calibs[1][2] +
			  g_matrix[2][2]*calibs[2][2] +
			  g_matrix[2][3]*calibs[3][2];
	x[0][1][3] = g_matrix[3][1]*calibs[1][2] +
			  g_matrix[3][2]*calibs[2][2] +
			  g_matrix[3][3]*calibs[3][2];
	printf("2nd:");
	for (l=1;l<=3;l++) printf("%12.6f",x[0][1][l]);
	printf("\n");

	x[0][1][1] = g_matrix[1][1]*calibs[1][3] +
			  g_matrix[1][2]*calibs[2][3] +
			  g_matrix[1][3]*calibs[3][3];
	x[0][1][2] = g_matrix[2][1]*calibs[1][3] +
			  g_matrix[2][2]*calibs[2][3] +
			  g_matrix[2][3]*calibs[3][3];
	x[0][1][3] = g_matrix[3][1]*calibs[1][3] +
			  g_matrix[3][2]*calibs[2][3] +
			  g_matrix[3][3]*calibs[3][3];
	printf("3rd:");
	for (l=1;l<=3;l++) printf("%12.6f",x[0][1][l]);
	printf("\n");

	x[0][1][1] = g_matrix[1][1]*calibs[1][4] +
			  g_matrix[1][2]*calibs[2][4] +
			  g_matrix[1][3]*calibs[3][4];
	x[0][1][2] = g_matrix[2][1]*calibs[1][4] +
			  g_matrix[2][2]*calibs[2][4] +
			  g_matrix[2][3]*calibs[3][4];
	x[0][1][3] = g_matrix[3][1]*calibs[1][4] +
			  g_matrix[3][2]*calibs[2][4] +
			  g_matrix[3][3]*calibs[3][4];
	printf("4th:");
	for (l=1;l<=3;l++) printf("%12.6f",x[0][1][l]);
	printf("\n");

	x[0][1][1] = g_matrix[1][1]*calibs[1][5] +
			  g_matrix[1][2]*calibs[2][5] +
			  g_matrix[1][3]*calibs[3][5];
	x[0][1][2] = g_matrix[2][1]*calibs[1][5] +
			  g_matrix[2][2]*calibs[2][5] +
			  g_matrix[2][3]*calibs[3][5];
	x[0][1][3] = g_matrix[3][1]*calibs[1][5] +
			  g_matrix[3][2]*calibs[2][5] +
			  g_matrix[3][3]*calibs[3][5];
	printf("5th:");
	for (l=1;l<=3;l++) printf("%12.6f",x[0][1][l]);
	printf("\n");
#endif /* DBG_LVL > 1 for debugging */
}

int check_sensor_pos()
{
	int temp_code=0;
	/* Jeong's original convert the coordinate */
	g_s[0] = g_matrix[1][1]*g_pos_data_s[0] +
		   g_matrix[1][2]*g_pos_data_s[1] +
		   g_matrix[1][3]*g_pos_data_s[2];
	g_s[1] = g_matrix[2][1]*g_pos_data_s[0] +
		   g_matrix[2][2]*g_pos_data_s[1] +
		   g_matrix[2][3]*g_pos_data_s[2];
	g_s[2] = g_matrix[3][1]*g_pos_data_s[0] +
		   g_matrix[3][2]*g_pos_data_s[1] +
		   g_matrix[3][3]*g_pos_data_s[2];

	g_s2[0] = g_matrix[1][1]*g_pos_data_s2[0] +
		   g_matrix[1][2]*g_pos_data_s2[1] +
		   g_matrix[1][3]*g_pos_data_s2[2];
	g_s2[1] = g_matrix[2][1]*g_pos_data_s2[0] +
		   g_matrix[2][2]*g_pos_data_s2[1] +
		   g_matrix[2][3]*g_pos_data_s2[2];
	g_s2[2] = g_matrix[3][1]*g_pos_data_s2[0] +
		   g_matrix[3][2]*g_pos_data_s2[1] +
		   g_matrix[3][3]*g_pos_data_s2[2];


	/* reached by the first sensor */
	/* (fabsf(g_s[2] - g_pos_data_t[2]) < 2) */
	if ( hypotf(g_s[0]-g_pos_data_t[0], g_s[1]-g_pos_data_t[1]) < t_test[0] )
		temp_code+=1;

	/* reached by the second sensor */
	if ( hypotf(g_s2[0]-g_pos_data_t[0], g_s2[1]-g_pos_data_t[1]) < t_test[0])
		temp_code+=10;

	return temp_code;
	
}




int check_hand_choice()
{
	float dist_right, dist_left;

//	Jeong's selection code: distance between the current and the initial
//	dist_right = hypotf(g_s[0]-g_s_init[0], g_s[1]-g_s_init[1]);
//	dist_left = hypotf(g_s2[0]-g_s2_init[0], g_s2[1]-g_s2_init[1]);

//	Cheol's selection code: distance between the current and the target. 
//	Cut from the previous function.
	dist_right = hypotf(g_s[0]-g_pos_data_t[0], g_s[1]-g_pos_data_t[1]) ;
	dist_left = hypotf(g_s2[0]-g_pos_data_t[0], g_s2[1]-g_pos_data_t[1]) ;

//	if (dist_right > dist_left)	//Jeong's selection
	if (dist_right < dist_left)	//Cheol's selection (reverse to Jeong's)
		return 1;
	else if (dist_right == dist_left)
		return 0;
	else
		return -1;
}



void display_init()
{
	int i;
	struct timeval tv;
	struct timezone tz;

	gettimeofday(&tv, &tz);
	srandom((unsigned int)tv.tv_usec);
	g_pos_data_t[0] = 0;
	g_pos_data_t[1] = 0;
	g_pos_data_t[2] = -5;

	/* set the matrix to an identity matrix as default */
	g_matrix = matrix(1,3,1,3);
	for (i = 1; i <= 3; i++)
		g_matrix[i][i] = 1.0;

	g_calibs = matrix(1,3,1,5);
	g_calibt = matrix(1,3,1,5);
	g_calibt[1][1]=-0.8;g_calibt[2][1]= 0.8;g_calibt[3][1]=-5.0;
	g_calibt[1][2]= 0.8;g_calibt[2][2]= 0.8;g_calibt[3][2]=-5.0;
	g_calibt[1][3]= 0.8;g_calibt[2][3]=-0.8;g_calibt[3][3]=-5.0;
	g_calibt[1][4]=-0.8;g_calibt[2][4]=-0.8;g_calibt[3][4]=-5.0;
	g_calibt[1][5]= 0.0;g_calibt[2][5]= 0.0;g_calibt[3][5]=-5.0;

	for (i = 1; i <= 5; i++)
		g_calibt[1][i] *= g_ratio;

}

void idledisplay()
{
	int temp,i, is_reached = 0;
	char s[256], fname[256];
	float error_s1, error_s2, final_error;

	/* display each scene */
	switch (g_scene) {
	case SC_CALIB_INFO:
		display_init();
		break;
	case SC_CALIB_LU:
	case SC_CALIB_RU:
	case SC_CALIB_RB:
	case SC_CALIB_LB:
	case SC_CALIB_C:
		break;

	/* start the test */
	case SC_TEST_INFO:
		break;
	case SC_TEST_READY1:
		g_scene++;		/* move to the next scene. */
	memcpy(c,  &g_scene,  sizeof(int));
	nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
	printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);
		target_displayed_gui=0;
		break;
	case SC_TEST_READY2:
	        flag_direction=0;selected_hand=0;
		//usleep(3000000);
		usleep(ITT*1000);
		g_scene++;		/* move to the next scene. */
	memcpy(c,  &g_scene,  sizeof(int));
	nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
	printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);

		/* record the initial sensor positions */
		check_sensor_pos();
		memcpy(g_s_init,  g_s,  sizeof(fpos));
		memcpy(g_s2_init, g_s2, sizeof(fpos));
		printf("[Init]\n%2.2f %2.2f %2.2f %2.2f %2.2f %2.2f\n\n",
			g_pos_data_t[0],g_pos_data_t[1],
			g_s_init[0],g_s_init[1],g_s2_init[0],g_s2_init[1]);

		/* to measure the lap time of the first trial for every target */
		target_displayed_gui=1;
		gettimeofday(&t_start,NULL);
		sensor_clear_crap();
		break;
	case SC_TEST_GO:
		/* start a test for reaching task */
		if (target_displayed_gui==0) {
			gettimeofday(&t_start,NULL);
			sensor_clear_crap();
			break;
			}
//		if (flag_direction==0)
//		  {
		g_pos_data_t[0] =    0 + g_pos_test[g_sched[cnt_target-1]-1][0]/g_real_w*g_ratio;
		g_pos_data_t[1] = -0.8 + g_pos_test[g_sched[cnt_target-1]-1][1]/g_real_h;
//		  }
//		else
//		  {
//		    g_pos_data_t[0]= 0;
//		    g_pos_data_t[1]= -0.8;
//		  }

		/* check whether the target is reached or not */
		sensor_get_pos();

		gettimeofday(&t_end,NULL);

		is_reached = check_sensor_pos();
//		if (selected_hand >0 && selected_hand!=is_reached)
//				is_reached=0;
		
		dprintf_cr(1, "\n");
		dprintf(1, "s:\t%7.2f\t%7.2f\n", g_s[0], g_s[1]);
		dprintf(1, "s2:\t%7.2f\t%7.2f\n", g_s2[0], g_s2[1]);
		dprintf(1, "t:\t%7.2f\t%7.2f\n", g_pos_data_t[0], g_pos_data_t[1]);

		/* check whether it contains noise or not */
//		dist_right = hypotf(g_s[0]-g_s_init[0], g_s[1]-g_s_init[1]);
//		dist_left = hypotf(g_s2[0]-g_s2_init[0], g_s2[1]-g_s2_init[1]);
//		if (dist_right>1.5 || dist_left>1.5)
//			break;

		/* record the result */
		g_result_data[cnt_trial-1].s[0] = g_s[0]*g_real_w/g_ratio;
		g_result_data[cnt_trial-1].s[1] = (g_s[1]+0.8)*g_real_h;
		g_result_data[cnt_trial-1].s2[0] = g_s2[0]*g_real_w/g_ratio;
		g_result_data[cnt_trial-1].s2[1] = (g_s2[1]+0.8)*g_real_h;
		g_result_data[cnt_trial-1].t[0] = g_pos_data_t[0]*g_real_w/g_ratio;
		g_result_data[cnt_trial-1].t[1] = (g_pos_data_t[1]+0.8)*g_real_h;
		if (cnt_trial == 1) {
			g_result_data[cnt_trial-1].time =
			(1000000*(t_end.tv_sec-t_start.tv_sec)+t_end.tv_usec-t_start.tv_usec)/1000;
		} else {
			g_result_data[cnt_trial-1].time = g_result_data[cnt_trial-2].time+
			(1000000*(t_end.tv_sec-t_start.tv_sec)+t_end.tv_usec-t_start.tv_usec)/1000;
		}

		if ( is_reached>0 ||
		     ( (g_result_data[cnt_trial-1].time-g_result_data[0].time) >
			   maxtime ) ) {	
		// note there is no "not reached in the backward direction within time constraint"

			dprintf(0, "%s (%d) to reach the %dth target by %d trials\n",
						is_reached?"succeed":"fail",
						is_reached, cnt_target, cnt_trial);

			/* generate a beep sound */
			if (is_reached>0)
				{temp=99;
				BEEP_SUCCESS();}
			else
				{temp=98;
				BEEP_FAILURE();}
			
			// send signal to the bart_gui, 99 success and 98 fail
			memcpy(c,  &temp,  sizeof(int));
			nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
			printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);

		printf("[%d] isreached:%d, selected_hand:%d, direction:%d,[%2.2f,%2.2f]\n",cnt_trial,is_reached,selected_hand,flag_direction,g_pos_data_t[0],g_pos_data_t[1]);

			/* create a file to save data */
			if (g_fp == NULL) {
				sprintf(fname, "%s/Traj-%d.txt", LOGDIR, cnt_target);

				if ((g_fp = fopen(fname, "w+")) == NULL) {
					dprintf(0, "fopen error: %s\n", strerror(errno));
				} else {
					sprintf(s, "#%s \t%-15s \t%-15s \t%-15s\n",
							   "Time", "Sensor1", "Sensor2", "Target");
					fwrite(s, 1, strlen(s), g_fp);
					sprintf(s, "%s\n",
		"#================================================================");
					fwrite(s, 1, strlen(s), g_fp);
				}
			} /* if (g_fp != NULL) */
			
			/* save data as a file. */
			sprintf(s, "\n");
			fwrite(s, 1, strlen(s), g_fp);

			for (i = 0; i < cnt_trial; i++) {
				sprintf(s,
					"%-7ld \t%3.2f, %3.2f \t%3.2f, %3.2f \t%3.2f, %3.2f\n",
					 g_result_data[i].time,
					 g_result_data[i].s[0], g_result_data[i].s[1],
					 g_result_data[i].s2[0], g_result_data[i].s2[1],
					 g_result_data[i].t[0], g_result_data[i].t[1]);

				fwrite(s, 1, strlen(s), g_fp);
			}

			fclose(g_fp);
			g_fp = NULL;

			if (g_logfp == NULL) {
				if ((g_logfp = fopen(LOGFILE, "a+")) == NULL) {
					dprintf(0, "fopen error: %s\n", strerror(errno));
				} else {
					sprintf(s, "#%s \t%s %s %s %s %s\n",
							   "Trial", "Target Position", "Movement Time",
							   "Error", "Hit", "Hand");
					fwrite(s, 1, strlen(s), g_logfp);
					sprintf(s, "%s\n",
		"#================================================================");
					fwrite(s, 1, strlen(s), g_logfp);
				}
			}
			
			error_s1 =
				hypotf( g_result_data[cnt_trial-1].t[0]-g_result_data[cnt_trial-1].s[0], g_result_data[cnt_trial-1].t[1]-g_result_data[cnt_trial-1].s[1]);
			error_s2 =
				hypotf( g_result_data[cnt_trial-1].t[0]-g_result_data[cnt_trial-1].s2[0], g_result_data[cnt_trial-1].t[1]-g_result_data[cnt_trial-1].s2[1]);
			final_error = (error_s1 < error_s2) ? error_s1 : error_s2;

			fprintf(g_logfp,
				"%-5d \t%3.2f, %3.2f \t%ld \t%3.2f \t%d \t%d\n",
				cnt_target,
				g_result_data[cnt_trial-1].t[0],
				g_result_data[cnt_trial-1].t[1],
				g_result_data[cnt_trial-1].time,
				final_error, (is_reached > 0), check_hand_choice());
//			if (flag_direction==0)
//			  {
//			    flag_direction=1;
//				selected_hand=is_reached;
//			    is_reached=0;
//			  }
//			else
//			  {
			cnt_target++;				/* move to the next target */
			cnt_trial = 1;
			is_reached = 0;
//			  }
			/* if every target has tried, go to the next step. */
			if (cnt_target > maxtarget)
				{g_scene = SC_END;
				memcpy(c,  &g_scene,  sizeof(int));
				nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
				printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);
				}
			else
				{
				g_scene = SC_TEST_READY1;
				memcpy(c,  &g_scene,  sizeof(int));
				nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
				printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);
				}

		} else {
			cnt_trial++;				/* try again with the same target */
		}	/* if (cnt_trial == maxtrial || is_reached) */

		gettimeofday(&t_start,NULL);

		break;
	case SC_END:
		/* close the file */
		if (g_fp) {
			fclose(g_fp);
			g_fp = NULL;
		}

		if (g_logfp) {
			fclose(g_logfp);
			g_logfp = NULL;
		}
		break;
	}	/* switch(g_scene) */


}

void keyboard(int key)
{
	if (g_scene == SC_END)
		exit(0);

	switch (key) {
	/* go to the next step or go to start */
	case 1:	//KEY_ENTER
	//case KEY_ENT:	//KEY_ENTER

		if (SC_CALIB_LU <= g_scene && g_scene <= SC_CALIB_C) {
			/* screen calibration */
			printf("start calib\n");
			sensor_clear_crap();
			sensor_get_pos();
			printf("%2.3f %2.3f %2.3f\n",g_pos_data_s[0],g_pos_data_s[1],g_pos_data_s[2]);
			sensor_get_pos();
			printf("%2.3f %2.3f %2.3f\n",g_pos_data_s[0],g_pos_data_s[1],g_pos_data_s[2]);
			sensor_get_pos();
			printf("%2.3f %2.3f %2.3f\n",g_pos_data_s[0],g_pos_data_s[1],g_pos_data_s[2]);
			sensor_get_pos();
			printf("%2.3f %2.3f %2.3f\n",g_pos_data_s[0],g_pos_data_s[1],g_pos_data_s[2]);
			sensor_get_pos();
			printf("%2.3f %2.3f %2.3f\n",g_pos_data_s[0],g_pos_data_s[1],g_pos_data_s[2]);
			g_calibs[1][cnt_calib] = g_pos_data_s[0];
			g_calibs[2][cnt_calib] = g_pos_data_s[1];
			g_calibs[3][cnt_calib] = g_pos_data_s[2];
			if (g_scene == SC_CALIB_C) calib_screen();

			BEEP_SUCCESS();
			cnt_calib++;
		} else if (SC_TEST_READY1 <= g_scene) {
			/* we don't have any more steps to skip. */
			break;
		}

		g_scene++;
	memcpy(c,  &g_scene,  sizeof(int));
	nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
	printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);
		break;

	/* skip this step */
	case 2: //SPACE
	//case KEY_SPACE: //SPACE
		if (g_scene == SC_CALIB_INFO)
			g_scene = SC_TEST_INFO;
		else if (g_scene == SC_TEST_INFO)
			g_scene = SC_END;
	memcpy(c,  &g_scene,  sizeof(int));
	nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
	printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);

		break;

	/* end a program */
	//case KEY_ESC: //ESC
	case 3:
		if (g_fp)
			fclose(g_fp);
		if (g_logfp)
			fclose(g_logfp);
		exit(0);
	case 8: // BART GUI said, the target is displayed
		target_displayed_gui=1;
		break;
	case 9:	//BART GUI said, I am up.
		g_scene=0;
		memcpy(c,  &g_scene,  sizeof(int));
		nret=WriteMsgToUnixUDP(udp_id,"./bart_gui.tmp",c,4);
		printf("[udp:%d] [gscene:%d] %s [%d]\n",udp_id,g_scene,c,nret);

	}
	
}

int main(int argc, char **argv)
{
	int temp; 
	char s[256], fname[256], sc[256];
	time_t tm=time(NULL);;
	struct tm *tmp;
	tmp = localtime(&tm);
	strftime(s, 100, "-%m%d%Y-%H%M", tmp);

	printf("Subject Code? ");
	gets(sc);
	printf("Forced(0)? or Free(1)? ");
	scanf("%d",&setup_condition);
	
	if (argc > 1)
	   {
       strncat(LOGDIR,argv[1],strlen(argv[1]));
	   }
	else
	   {
		   if (strlen(sc)==0)
		    {
	   		char temp2[255]="log";
       			strncat(LOGDIR,temp2,strlen(temp2));
	   		}
		   else
			{
			strncat(LOGDIR,sc,strlen(sc));
			}
       }
       strncat(LOGDIR,s,strlen(s));
	strncat(LOGFILE,LOGDIR,strlen(LOGDIR));
	strncat(LOGFILE,temp_char,strlen(temp_char));


    	



	loadparam();
	printf("The LOG directory is %s\n",LOGDIR);
	printf("The LOG FILE is %s\n",LOGFILE);
        printf("# of Targets = %d\n\n",maxtarget);
	
	serfd=config_serial();
	
	udp_id=CreateUnixUDP("./bart_core.tmp");


	
	while(1)
	{
                FD_ZERO(&rfds);
                FD_SET(0, &rfds);
                FD_SET(udp_id, &rfds);
		FD_SET(serfd,&rfds);

                /* Wait up to five seconds. */
              	tv.tv_sec = 1;
              	tv.tv_usec = 0;
 				if( select(20, &rfds, NULL, NULL, &tv ) < 0 )
                {
                        printf("Select error!!![%s]",strerror(errno));
                }

                if(FD_ISSET(udp_id,&rfds))
                {
		nret = ReadMsgFromUnixUDP(udp_id,c,4);
		if( nret > 0 )
			{
			//printf("%s[%d]\n",c,nret);
			temp=(int)(c[0] | c[1]<<8 | c[2] <<16 | c[3]<<24 );
			printf("receive %d[%d]\n",temp,nret);

			keyboard(temp);
			}
		}
                if(FD_ISSET(serfd,&rfds))
                {
		idledisplay();
//		sensor_get_pos();
//		printf("%f %f %f %f %f %f\n",sensor[0][0],sensor[1][0],sensor[2][0],
//			sensor[0][1],sensor[1][1],sensor[2][1]);
		}

	}
	
	sensor_finalize();

	return(0);
}


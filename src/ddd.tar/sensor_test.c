#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>


#include <strings.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/io.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

#include "global.h"

#include "debug.h"
#include "sensor.h"
#include "command.h"

#include "nr.h"
#include "nrutil.h"

#define MAXBUF	8192

float sensor[3][2];
fpos g_pos_data_t;		// the position of a target
fpos g_pos_data_s;		// the position of the first sensor
fpos g_pos_data_s2;		// the position of the first sensor

int main(int argc, char **argv)
{
	int c, i = 0,j;
	float *pos_data_s;
	char s[256], fname[256];
	FILE *fp = NULL;
	time_t tm;
	struct tm *tmp;
	struct timeval t_current, t_start, t_samp_st, t_samp_end;
	struct result_data result_data[MAXBUF];
	float	wristTau,xForce,yForce,zForce;
	int count_byte;

        int bufsize = 1024*8;
        char *buffer = malloc(bufsize);
	char buffer_actual[MAXBUFSIZE];
	short	birddata[MAXBUFSIZE];

        fd_set  rfds;
        struct  timeval tv;
        int     retval;


config_serial();
pos_data_s = (float *)malloc(3*sizeof(float));

	printf("\nPress any keys to start to recode:");
	c = getchar();

	tm = time(NULL);


	/* start a test */
	gettimeofday(&t_start,NULL);

	int	tSample;
	printf("Opened serial port:%d\n",serfd);
	
	// delete all previous datas//
	sensor_clear_crap();

	while (1) {
                /* Watch stdin (fd 0) to see when it has input. */
                FD_ZERO(&rfds);
                FD_SET(0, &rfds);
                FD_SET(serfd, &rfds);

                /* Wait up to five seconds. */
              	tv.tv_sec = 5;
              	tv.tv_usec = 0;

                if( select(20, &rfds, NULL, NULL, &tv ) < 0 )
                {
                        printf("Select error!!![%s]",strerror(errno));
                }

                if(FD_ISSET(serfd,&rfds))
                {
//					printf("selected %d\n",serfd);
                        //if( (retval=read( serfd, buffer, 14 ))<0 )
                        //{
                        //        printf("read from serial error:%s", strerror(errno));
                        //}
				

			sensor_get_pos();
   printf("%f %f %f %f %f %f\n",sensor[0][0],sensor[1][0],sensor[2][0],
		sensor[0][1],sensor[1][1],sensor[2][1]);
                }



		gettimeofday(&t_samp_st,NULL);
		gettimeofday(&t_samp_end,NULL);
		tSample = t_samp_end.tv_sec*1000000+t_samp_end.tv_usec; 
//		tSample = (t_samp_st.tv_sec - t_samp_end.tv_sec)*1000000+(t_samp_st.tv_usec-t_samp_end.tv_usec); 


#if 0 

		if( i==3 )
		{
			bird_anglealign(pos_data_s);
			sleep(1);	
			
		}
#endif

		

		gettimeofday(&t_current,NULL);
		if ((t_current.tv_sec - t_start.tv_sec) > 10) {
			printf("Now exiting..\n");
			break;
		}

		i++;
	}



	free(pos_data_s);

//	sensor_finalize();

	return(0);
}

